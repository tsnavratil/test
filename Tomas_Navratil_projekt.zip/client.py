class Client:
    """
    Class represents insured person.
    """

    def __init__(self, name, surname, age, phone_number):
        """
        :param name:    client name
        :param surname: client surname
        :param age:     client age
        :param phone_number: client phone_number
        """
        self.name = name
        self.surname = surname
        self.age = age
        self.phone_number = phone_number

    def __str__(self):
        """
        Returns text representation - parameters of client.
        """
        return str("{0} {1} {2} {3}".format(self.name, self.surname, self.age, self.phone_number))










