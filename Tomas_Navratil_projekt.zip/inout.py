class Input_output:
    """
    Class represents input and output
    """
    def __init__(self):
        """
        input_messages - texts for print into console
        """
        self.input_messages = ["Enter the name of insured client:", "Enter the surname of insured client:",
                                 "Enter the phone number:", "Enter the age:"]

    def print_start_menu(self):
        """
        Method prints start menu
        """
        self.__clean_console()
        print("---------------------------------------------------")
        print("Records of insured persons")
        print("---------------------------------------------------")
        print()
        print("Choose the action:")
        print("1 - Add a new insured client")
        print("2 - Write out all insured clients")
        print("3 - Search the insured client")
        print("4 - End")

    def __clean_console(self):
        """
        Method cleans console
        """
        import sys as _sys
        import subprocess as _subprocess
        if _sys.platform.startswith("win"):
            _subprocess.call(["cmd.exe", "/C", "cls"])
        else:
            _subprocess.call(["clear"])

    def read_action(self, text_entry, text_error):
        """
        Method is for input text from the user input.
        """
        bad = True
        while bad:
            try:
                number = int(input(text_entry))
                bad = False
            except ValueError:
                print(text_error)
        else:
            return number


    def data_input(self, number_of_items):
        """
        Method reads data from input.
        Data are stored into field.
        """
        data = []
        for j in range(number_of_items):
            input_info = input(self.input_messages[j] + "\n")  # text on new row
            data.append(input_info)
        return data


