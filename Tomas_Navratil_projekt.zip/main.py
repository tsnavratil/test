"""
    Main program - Records of insured persons
"""
# Imported moduls
from client import Client
from storage import Storage
from inout import Input_output

# main program
def main():
    inout1 = Input_output()    #instance of input/output1
    memory1 = Storage(inout1)   #instance of memory1, parameter is instance of inout1

    while True:
        inout1.print_start_menu()  # print start menu
        number_of_action = inout1.read_action("", "Invalid entry!\n") #user will choose action
        print()     #insert free row into console

        if number_of_action == 1:       # 1-add new insured person
            memory1.add_data()   #save data about client
            print("\nData was saved. Continue any key...")
            input()

        elif number_of_action == 2:     # 2-write out all insured persons
            number_of_items = memory1.get_number_items()    #number of clients
            for i in range(number_of_items):
                item = memory1.read_one_item(i)   #one client
                print("  ".join(item))            #print clients
            print("\nContinue any key...")
            input()

        elif number_of_action == 3:     # 3-search insured person

            data = memory1.input_data_for_searching() #read name and surname data for searching
            number_of_items = memory1.get_number_items()  # number of all clients

            for i in range(number_of_items):
                item = memory1.read_one_item(i)  # read all info about wanted client
                success = False
                if ((data[0] == item[0]) and (data[1] == item[1])):
                    print()
                    print("  ".join(item))  # print client
                    success = True
                    break
            if not success:
                print("Insured person was not found!")
            print("\nContinue any key...")
            input()

        elif number_of_action == 4:     # 4-End
            print("Thank you for using this program.")
            break
        else:
            print("Invalid choice")  # user entered number outside range (1-4)

main()
