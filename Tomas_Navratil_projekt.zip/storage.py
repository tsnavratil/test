class Storage:
    """
    Class represents storage place for all clients.
    """
    def __init__(self, inout):
        """
        inout  instance of input/output
        """
        self.__storage = []  #storage for data
        self.__number_of_items = 0  #counter of items in storage
        self.__inout = inout

    def __str__(self):
        """
        Returns text representation - number of items in the storage
        """
        return str(self.__number_of_items)

    def get_number_items(self):
        """
        Returns number of items in the storage
        """
        return self.__number_of_items

    def add_data(self):
        """
        Method save data into storage.
        """
        data = self.__inout.data_input(4)  # read 4 parameters about client from input
        self.__storage.append(data)  # save data into storage
        self.__number_of_items = self.__number_of_items + 1  # raise counter

    def read_one_item(self, item):
        """
        Method reads one item from storage.
        """
        text = ("{0} {1} {3} {2}".format(self.__storage[item][0], self.__storage[item][1],self.__storage[item][2], self.__storage[item][3]))
        text = text.split(" ")
        return text

    def input_data_for_searching(self):
        """
        Method is for entering data for searching
        """
        data = self.__inout.data_input(2)  # read 2 parameters about client from input
        return data

